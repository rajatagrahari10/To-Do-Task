# Todo App
Simple ReactJs task manager 🔥

---

### Features

- Create a task
- Mark as completed
- Delete a task
- Data saved through local storage 📦 (Thanks to @thomasvaeth)
